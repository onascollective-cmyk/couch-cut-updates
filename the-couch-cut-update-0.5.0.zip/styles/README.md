# Looks

Each folder here is one look, with a `style.toml` of plain words and numbers. `./reel styles` lists them.

A new copy comes with three starter looks:

- **fresh**: clean and modern. Grotesque captions, one key word in a soft script, a pill on a name, an underline.
- **notebook**: hand drawn and friendly. Handwriting captions, big bold words, lined paper notes, tags and tape.
- **bold**: loud and editorial. Cards on the hook and the closer, big words, list tags, scenes behind the frame.

## Your own looks

On the first chat Claude asks a few multiple choice questions (how your videos should feel, your colors, your fonts, a name)
and makes a look of your own from one of the starters: `./reel style quiz`, then
`./reel style make sunny-days --from fresh --label "Sunny Days" --colors lilac-sky --fonts modern --default`.
You can make as many as you like, one for each kind of video. A name that is taken is never replaced.

## How a look works

Every look is drawn by one of five look engines (`base = "polished"` in its style.toml): simple, polished, over-the-top,
scribble or handmade. A look changes the engine's colors, fonts and sizes and keeps all of its pieces.

- `[palette]` the colors. Anything you set under Colors in `brand-kit.md` wins over these. `scene_*` colors are the card
  scenes and effects (sticky notes, tape, chart bars, the dark card behind the frame).
- `[fonts]` the font bundle: `serif`, `sans`, `display`, `handwriting`, `script`, each a file in `assets/fonts`
  (open license fonts only) or `yours:Name` for your own font in `assets/yours/fonts`.
- `[captions]`, `[hook]`, `[popups]` and the rest: sizes, where text sits, how it moves. The engine measures every piece
  of text before it builds and keeps the top 270 and bottom 300 pixels clear.
- Want to nudge a look without editing it? Say "remember this" (it saves to `preferences.toml`).

---
name: update
description: Get the newest version of The Couch Cut, free, with their clips, brand kit, license and settings left exactly as they are. Use when the owner types /update or /upgrade, or just the word "update" or "upgrade" on its own, or says "update the Couch Cut", "upgrade the Couch Cut", "get the newest version", "is there an update", "what's new", or "undo the update".
---

# Update (free updates for every copy)

The owner types `/update` (or `/upgrade`) (or says it in plain words) and gets the newest engine. Their clips, brand kit, license, own fonts and files, settings and every finished video are never touched. **Everything runs with `./reel upgrade`**; they never have to. Talk the way `CLAUDE.md` says: warm, plain, short, lead with hope, no jargon.

## What to do

1. Say one warm line: "Let me see if there is something new for you." Then run `./reel upgrade --check`. It says whether a newer version is out and what is new, and it changes nothing.
   - **Up to date**: tell them so, and stop. Don't run the upgrade.
   - **Newer version**: tell them what is new in their words (the notes it prints, shortened), then go to step 2. They typed `/update`, so that is the yes: don't ask again.
2. Run `./reel upgrade`. It takes about a minute, so say so ("this takes a minute, nothing of yours is touched"). It keeps a backup of everything it replaces, checks that the new version starts, and puts the old one back by itself if anything is off.
   - **A video is being made right now** (it says so): don't force it. Tell them it will go as soon as that video is done, and wait until it finishes, then run it again.
3. When it says it worked, tell them in two or three short lines: the new version, what is new, and that **they should start a new chat** so the newest instructions load (this chat is still running the old ones).
4. If it says it could not finish, read what it printed and tell them plainly what happened in one sentence. The old version is back and working, so their next video is not at risk. Don't try to fix the engine by hand and never copy files in yourself. The support email is in `START-HERE.html`: offer it only if a second try fails.

## Other things they may ask

- **"Undo the update" or "go back"**: `./reel upgrade --undo` puts the last version back (their settings stay as they are, only new lines were added to them). Say what it restored.
- **"What version do I have?"** `./reel upgrade --check` prints it.
- **"Can I update from a file the maker sent?"** `./reel upgrade --from <folder with latest.json and the zip>`. Only an update signed by the Couch Cut is accepted: anything else is refused, and that is on purpose.

## Never

- Never edit, copy over or delete anything in `engine/`, `.update/`, `license.key` or `LICENSE.txt` by hand, and never download an update any other way: the signed upgrade is the only way.
- Never run it while a video is being made, and never run it on the original (owner) copy: it says "this is the maker's own copy" and stops, which is right.
- Never talk about how updates are signed or built unless they ask.

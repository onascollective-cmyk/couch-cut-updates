# Styles

Each folder here is one look. Say "edit this reel, pizazz" (or simple, or middle) and the engine uses that folder's `style.toml`.

- **simple**: quiet and clean
- **middle**: soft and a little bouncy
- **pizazz**: playful and loud, in a good way
- **handmade**: your footage with paper, tape and stickers on top, and a graph paper card that breaks things up (your own Canva pictures go in `assets/yours/collage`)

## Make your own

Copy a folder, rename it, and edit its `style.toml`. Everything is plain words and numbers.

- `[palette]` the colors. Anything you set under Colors in `brand-kit.md` wins over these.
- `font = "Folder/File-Name"` points into `assets/fonts` (open license fonts only).
- `size` is CapCut's size number. CapCut draws one point as about 4.85 pixels on the 1080 wide frame, so 12 is about 58 pixels.
- `y` is where the middle of the text sits (the hook's `y` is its top edge). The engine moves anything that would leave the safe zone.
- `in`, `out`, `loop` are CapCut text animation names, like `Pop_Up`, `Bounce_In`, `Boing`, `Spring`, `Fade_In`, `Jiggle`.
- `mode = "cards"` shows a phrase at once (what all three styles use). `mode = "karaoke"` lights up the word being said.
- `accent_font = "@handwriting"` (in `[captions]`) turns the plan's key words into that font, in the highlight color. `accent_scale` makes it a little bigger, because handwriting runs small (1.2 to 1.5 matches the other words).
- Hook looks are separate: `toolbox/hooks.toml` holds five ready made ones (line, card, sparkle, behind, takeover) that a plan picks with `hook_style`, so any style can wear any hook.
- `outline = 0` means no outline. All three styles use none, with a soft shadow instead.
- `[footage] zoom` is `none`, `alternate` (every other clip is zoomed in) or `alternate_push` (plus a slow push in on the wide clips).

The engine measures every piece of text before it builds, and it will not build a draft with text in the top 270 or bottom 300 pixels.

## More you can set

- `motion = "boing"` (or any id from `toolbox/effects.toml`, like `whisper`, `pop`, `spring`, `typewriter`, `reveal`) replaces `in`, `out` and `loop` with a ready made text motion. Use it on `[captions]`, `[hook]`, `[popups]`, `[takeover]` or `[cards]`.
- `[captions] mode` can be `cards`, `karaoke` or `word` (one word at a time).
- `[takeover]` is the big phrase in the middle of the screen for a punchline. `[cards]` styles the title, list and compare cards.
- `[sound] level` is `off`, `light` or `lively`, and `volume` is 0 to 1. Sounds only play on teaching reels unless the plan asks.
- Want to nudge a style without editing it? Say "remember this" (it saves to `preferences.toml`), or make a one reel change in the plan's `overrides`.

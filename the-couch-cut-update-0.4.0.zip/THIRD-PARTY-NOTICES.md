# Third party notices

Everything in this folder that is not listed below was written fresh for Heather Onas
(the engine code, the docs and the skill). The free pieces it stands on are listed here,
each with its license. The full license text of each one ships with that piece.

The Couch Cut name and logo (`assets/brand`) belong to Heather Onas (Onas Collective). They are not an open license piece.

## The CapCut draft writer

| Piece | What it does here | License |
| --- | --- | --- |
| [VectCutAPI](https://github.com/sun-guannan/VectCutAPI) (commit `0596f17b`, fetched 2026-10-17) | Writes the editable CapCut draft. Kept in `vendor/VectCutAPI`, with its `LICENSE` unchanged. Unused parts (servers, cloud upload, examples) were removed. See `vendor/VectCutAPI/FETCHED-FROM.txt`. | Apache-2.0 |
| [pyJianYingDraft](https://github.com/GuanYixuan/pyJianYingDraft) by GuanYixuan | The draft writing library that VectCutAPI is built on. Included inside VectCutAPI (`vendor/VectCutAPI/pyJianYingDraft`). | Apache-2.0 |

## Listening (turning speech into words)

| Piece | What it does here | License |
| --- | --- | --- |
| [faster-whisper](https://github.com/SYSTRAN/faster-whisper) 1.2.1 | Speech to text, on the CPU | MIT |
| [CTranslate2](https://github.com/OpenNMT/CTranslate2) 4.8.3 | The fast engine under faster-whisper | MIT |
| [Whisper](https://github.com/openai/whisper) model weights by OpenAI, converted by Systran (`Systran/faster-whisper-small.en`) | The voice model, downloaded once into `models/` | MIT |
| [Silero VAD](https://github.com/snakers4/silero-vad) (shipped inside faster-whisper) | Voice activity model | MIT |
| [ONNX Runtime](https://github.com/microsoft/onnxruntime) 1.19.2 | Runs the Silero model | MIT |
| [PyAV](https://github.com/PyAV-Org/PyAV) 18.1.0 | Reads audio for the listener | BSD-3-Clause |
| [tokenizers](https://github.com/huggingface/tokenizers) 0.23.3 | Text pieces for the listener | Apache-2.0 |
| [huggingface_hub](https://github.com/huggingface/huggingface_hub) 2.2.0 | Downloads the voice model | Apache-2.0 |

## Python libraries used by the engine

| Piece | License |
| --- | --- |
| [NumPy](https://numpy.org) 2.4.6 | BSD-3-Clause (and a few permissive licenses for bundled parts) |
| [Pillow](https://python-pillow.org) 13.0.0 (the layout preview picture) | MIT-CMU |
| [ImageIO](https://imageio.readthedocs.io) 2.38.1 | BSD-2-Clause |
| [json5](https://github.com/dpranke/pyjson5) 0.17.3 | Apache-2.0 |

The listener and the libraries above also pull in small helpers (anyio, click, coloredlogs,
filelock, flatbuffers, fsspec, h11, hf-xet, httpcore2, httpx2, humanfriendly, idna, mpmath,
packaging, protobuf, PyYAML, sympy, tqdm, truststore, typing_extensions). They are all
installed by `uv sync` under permissive licenses (MIT, BSD, Apache-2.0, PSF-2.0, MPL-2.0).
`uv pip list` shows exactly what is installed.

## Programs the engine calls (not included in this folder)

| Piece | What it does here | License |
| --- | --- | --- |
| [FFmpeg / ffprobe](https://ffmpeg.org) (this Mac's copy is a static build from evermeet.cx) | Reads clips, extracts audio, makes the cover picture | LGPL / GPL, depending on the build. This build includes GPL parts, so it is GPL. It is used as a separate program and is not redistributed here. |
| [uv](https://github.com/astral-sh/uv) | Sets up the Python tools | Apache-2.0 or MIT |
| [Python](https://www.python.org) 3.11 | Runs the engine | PSF License |
| CapCut | The editor you open the draft in. The engine only writes draft files that CapCut can read, and never changes the app. | Proprietary (not part of this engine) |

## Fonts

Each font ships in `assets/fonts/<Family>` with its license text. All are SIL Open Font License 1.1, which allows use in a product that is sold, except Satisfy, which is Apache License 2.0 (also fine). The fonts themselves just can't be sold on their own. Every look has a bundle of four: a serif, a sans serif, a handwriting and a script.

| Font | Role | Authors | License |
| --- | --- | --- | --- |
| [Instrument Serif](https://github.com/Instrument/instrument-serif) | Over the Top one word captions and list tags (regular and italic) | The Instrument Serif Project Authors | OFL 1.1 |
| Statement Serif (cut from [Playfair Display](https://github.com/clauseggers/Playfair-Display)) | Simple hook (Bold) and Over the Top big words (Black) | The Playfair Display Project Authors | OFL 1.1 |
| [Instrument Sans](https://github.com/Instrument/instrument-sans) | Menu page | The Instrument Sans Project Authors | OFL 1.1 |
| [Poppins](https://github.com/itfoundry/Poppins) | Simple captions | The Poppins Project Authors | OFL 1.1 |
| [DM Sans](https://github.com/googlefonts/dm-fonts) (variable font, fetched from the Google Fonts repository on 2026-10-17) | Polished hook and captions, | Colophon Foundry, Jonathan Barnbrook, Indian Type Foundry | OFL 1.1 |
| [Shrikhand](https://github.com/jonpinhorn/shrikhand) (fetched from the Google Fonts repository on 2026-10-17) | Polished key word | Jonny Pinhorn | OFL 1.1 |
| [Patrick Hand](https://fonts.google.com/specimen/Patrick+Hand) | Archived looks only | Patrick Wagesreiter | OFL 1.1 |
| [Caveat](https://github.com/googlefonts/caveat) | Over the Top script lines and polaroid captions, and the stand in for Ugly Dave in Scribble when it is not installed | The Caveat Project Authors | OFL 1.1 |
| [Satisfy](https://fonts.google.com/specimen/Satisfy) | Archived looks only | Sideshow | Apache 2.0 |
| [Kaushan Script](https://fonts.google.com/specimen/Kaushan+Script) | Archived looks only | Impallari Type | OFL 1.1 |
| [Pacifico](https://github.com/googlefonts/Pacifico) | Archived looks only | The Pacifico Project Authors | OFL 1.1 |
| [Bricolage Grotesque](https://github.com/ateliertriay/bricolage), Instrument Sans, [IBM Plex Mono](https://github.com/IBM/plex) | The Couch Cut Menu page (Bricolage Extra Bold is also the big caps hook font) | Their project authors (IBM Corp. for Plex) | OFL 1.1 |

Logos: the engine ships none. The demo window can show a logo you drop into `assets/yours` yourself, and that folder is never packaged. Use only logos you are allowed to use.

Notes on how some files were prepared: Caveat, Bricolage Grotesque and Instrument Sans are shipped as fixed weights cut from the variable fonts on Google Fonts, because CapCut needs one file per weight. Playfair Display's license reserves its name, so the fixed weights cut from it are called Statement Serif (see `assets/fonts/StatementSerif/README.txt`). The glyphs are unchanged. Poppins, Instrument Serif, Patrick Hand, Kaushan Script, Pacifico, Satisfy and IBM Plex Mono are the original files.

Only open license fonts (SIL OFL, Apache or similar) go in `assets/fonts`. Personal use fonts never do.

**Ugly Dave** (the Scribble handwriting) is Heather's own font file. It lives in `assets/yours/fonts`, never in `assets/fonts`, and `./reel package` leaves that folder out. A copy of The Couch Cut without it falls back to Caveat for Scribble. The same goes for Missing Lovely (the Over the Top script in Heather's Scrapbook pack): it is not in this folder yet, so Caveat stands in.

## Cutout (background removal)

| Piece | What it does here | License |
| --- | --- | --- |
| [MODNet](https://github.com/ZHKKKe/MODNet), as an ONNX file by Xenova (`Xenova/modnet` on Hugging Face) | Works out which pixels are you, so words can sit behind your head. Downloaded once into `models/cutout`. | Apache-2.0 |
| ProRes 4444 encoder in FFmpeg | Writes the short see through clip of you | See FFmpeg above |

## Faces (blurring faces)

| Piece | What it does here | License |
| --- | --- | --- |
| [Ultra-Light-Fast-Generic-Face-Detector-1MB](https://github.com/Linzaer/Ultra-Light-Fast-Generic-Face-Detector-1MB) (`version-RFB-640.onnx`, 1.5 MB, by Linzaer) | Finds faces in a clip so one can be blurred. Downloaded once into `models/faces` by `./reel setup` (checked against a fixed checksum), run with ONNX Runtime above. Nothing leaves the computer. | MIT |

The engine can also place small animated pictures (`finish.gifs`) and music (`finish.music`) that the owner supplies in `assets/yours`. None are shipped. Each owner is responsible for having the right to use what they add; the engine prints and saves any credit line that comes with a library item.

## Sounds

The 12 sound effects in `assets/sounds` were made by this engine's own sound maker (`engine/soundkit.py`, run with `./reel sounds`). Each is built from plain tones and noise, so none of them is a recording or sample from anyone else. They are original to this engine and free to use in reels and to ship with it.

If recorded sounds are ever added, only public domain or clearly free licensed ones will go in `assets/sounds`, each listed here with where it came from and its license.

# Sounds

These sound effects were made by the engine's own sound maker (`./reel sounds`). They are built from plain tones and noise, so they are original and free to use and to sell with the engine.

Add your own by dropping a `.wav` here and listing it in `effects/library.toml`. If you add recorded sounds, only use public domain or clearly free licensed ones, and list each in `THIRD-PARTY-NOTICES.md`.

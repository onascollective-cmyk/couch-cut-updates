Pictures of your own for the card scenes in Over the Top (the hook and the closer).

Drop screenshots, product shots, logos or a photo of the thing you are talking about here (PNG, JPG or WebP).
The wall, the orbit and the notes scenes use these first and fill the rest with frames of your own footage.
Only use pictures you are allowed to use. Nothing is drawn or generated for you, and this folder is never packaged with the engine.
To use specific files for one reel, list them in its plan: "finish": {"images": ["assets/yours/scenes/app-home.png"]}

Your own logos go here (PNG, JPG or WEBP).

The demo window can show a logo in its title bar. Put the logo file in this folder, then ask for it by name,
like: assets/yours/my-logo.png

Why a folder of your own: a logo belongs to whoever owns the brand, so this engine never draws one and never
ships one. Use only logos you are allowed to use, and follow that brand's own usage rules. Nothing in this folder
is included when the engine is packaged for someone else.

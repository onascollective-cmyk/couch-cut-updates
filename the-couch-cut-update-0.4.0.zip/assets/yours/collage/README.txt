Your own Canva pictures for the Handmade look go here.

Make each one in Canva and export it as a PNG with a see through background (Download, PNG, Transparent background).
Good first ones: a star, a sparkle cluster, scissors, a little couch, an arrow, a circled scribble, an underline squiggle,
question marks, a heart. The engine already draws graph paper, tape, sticky notes, torn notebook pages, labels and thought
clouds by itself, in your palette, with your words on them. These pictures are the extras that make it yours.

Ask for one on a word in the edit plan, like: {"at": 52, "file": "star.png", "size": 240, "side": "right", "seconds": 2}

Only pictures you made or are allowed to use. This folder is never included when the engine is packaged for someone else.

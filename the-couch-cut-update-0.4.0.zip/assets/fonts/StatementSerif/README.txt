Statement Serif is Playfair Display (SIL Open Font License 1.1, see LICENSE-OFL.txt) cut into fixed weights
(SemiBold, Bold, Black) because CapCut needs one file per weight. The license reserves the name
"Playfair Display" for the original, so these cut versions carry a different name.
Original: https://github.com/clauseggers/Playfair-Display  (Google Fonts: Playfair Display)

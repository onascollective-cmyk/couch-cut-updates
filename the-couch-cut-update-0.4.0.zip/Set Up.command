#!/bin/bash
# Double click this to set everything up the first time.
cd "$(dirname "$0")" || exit 1
./reel setup
echo
read -n 1 -s -r -p "Press any key to close this window."

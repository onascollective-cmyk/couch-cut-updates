<p align="center"><img src="assets/brand/the-couch-cut-logo.png" alt="The Couch Cut" width="260"></p>

# The Couch Cut

You film. The engine edits. Drop a clip in, say what you want, and get back finished videos you can post as they are, in four looks.

It only edits. It never posts or schedules anything.

## Who can use this

Before you buy or set up, make sure you have all of these. If one is missing, The Couch Cut won't run.

| You need | Why |
| --- | --- |
| **A Mac** (Apple silicon or Intel) | The engine uses Mac folders. Windows and Chromebooks don't work yet. Phones and iPads don't work either. |
| **Claude, with Claude Code** | Claude is the editor you talk to. You need a paid Claude plan that includes Claude Code, using either the Code tab in the Claude desktop app or Claude Code in Terminal. The free plan and the regular chat window can't open this folder. |
| **Homebrew** (free) | Setup uses it to install the video tools (ffmpeg). Get it at brew.sh, or ask Claude to help you install it. |
| **About 3 GB of free space** | For the voice model (about 500 MB), the cutout model, the video tools and a working copy of each clip. |
| **Internet for the first setup** | Everything downloads once, including uv, the free tool that sets up the engine (setup installs it for you). After that, editing runs on your own Mac. |
| **A few minutes of patience** | First setup takes a few minutes. Listening to a clip takes about 3 times its length, and each finished look takes a few minutes to draw. |

Optional: **Google Drive for desktop** (free), if you want to drop clips in a Drive folder, say from your phone, and get the finished videos back in another. It's off to start with. Claude offers it once on your first run, or any time say **"set up Google Drive"** (and **"turn off Google Drive"** to stop). **CapCut desktop**, if you ever want an editable draft (ask for it with "and CapCut").

**It's a good fit if** you film talking head reels (vertical is best) and want the cut, captions, hook and a look done for you.

**It's not for you (yet) if** you're on Windows, only edit on your phone, want it to post for you (it never posts), or don't want to use Claude.

## How to use it

1. Film your reel (vertical is best) and drop the clip in the **clips** folder (or, if you set up Google Drive, in your Drive folder **Couch Cut In**).
2. Open this folder in Claude and say **"edit this reel"**. Claude watches your video and picks the look that fits it. Want a different one, or a few to compare? Just say so: **"edit this reel, polished and scribble."**
3. Go grab a coffee. Listening takes a few minutes.
4. **Check your script.** Claude shows your transcript line by line, with what was kept and what was cut and why, plus a quick video of the cuts. Flip a line, fix a misheard word, or say "looks good".
5. Claude builds the one look that fits your video. Your finished video is in **finished/**, named after your clip and the look, like `my-clip-polished.mp4` (and in **Couch Cut Out** in Drive if you use it).

If you talk to Claude inside your clip ("Claude, add sound effects when I say that"), Claude does it and cuts that part out, unless keeping it makes the story make sense.

## Four looks

| Look | The feel |
| --- | --- |
| **Simple** | Just you, a hook, and the point. A tight cut, a serif hook at the top and plain white captions. Nothing else. |
| **Polished** | Clean like Simple, with a little extra. DM Sans captions, one pastel yellow Shrikhand key word, a mint highlight on the name, a light blue underline that draws itself. |
| **Over the Top** | Warm, a little messy, all yours. Your video drops into a frame on a card for the hook and the closer. In between: big serif words, taped photos from your own footage, butter yellow list tags, one word at a time captions. The card color goes with what you wear. |
| **Scribble** | Calm handwriting and one loud word. Thin white handwriting captions under your chin on full frame video and one big butter yellow word. Add your own screen recording for a blurred demo moment. |

Every look keeps your words, your rules (no dashes, swears starred, no invented numbers) and a clear top and bottom of the screen for the app buttons. The engine measures every word before it draws anything.

## The Edit Style Book

Open **edit-style-book.html** in your browser. It shows your four looks and every feature inside them, each with an ID like `CAP-06` and the exact words to say. Say the ID to Claude and it knows what you mean. `toolbox/style-book-index.txt` is the same list as plain text.

## What you get

- A tight edit. Pauses, false starts, fluff and repeats are cut. If you say a line twice, your **last** try is kept. Cuts land on real quiet, so no clipped words.
- It opens on your best moment, with a hook that doesn't repeat how you start.
- Captions that follow your brand rules, in a look you chose.
- A look chosen for you: Claude watches your video, reads your words and picks the look that fits it best (and builds only that one, unless you ask for more). Every look's length comes from your video, never from a preset.
- Smooth cuts: no word is ever clipped, and each clip's voice starts a hair before its picture (a J cut).
- Point and say a word, and a label or small animation that matches it appears right where you point.
- Finished 1080 x 1920 videos with the sound mixed in, ready to post. A CapCut draft only if you ask.

## Your files are safe

- Nothing is ever deleted without your yes. Your originals in Drive are only copied, never moved or changed.
- Each finished video is a new file. A second version gets a number. Nothing is overwritten.
- CapCut drafts (when you ask) go `1.1`, `1.2`, `1.3`, and the engine never touches CapCut while it is open.

## Make it yours

- **`brand-kit.md`** is your page: your name, voice, the words that get a star, the words you never use, your colors. Fill in a color and it beats every look's own. The engine reads it every time.
- **`engine.toml`** holds the settings and the engine's name. Everything inside the folder is relative, so you can rename or move the whole folder and nothing breaks.
- **`styles/`** holds the four looks. Each folder has a `style.toml` with the colors, fonts and sizes. Say "make the hook bigger" or "remember this" and Claude changes it for you.

## First time here?

Check the list in **Who can use this** first, then do these once. All together it takes about 15 to 30 minutes, mostly waiting.

1. **Install Homebrew.** It's a free app installer for Macs, and setup uses it to get the video tools.
   1. Open **Terminal** (press Cmd+Space, type Terminal, press Return).
   2. Go to **brew.sh**, copy the one line under "Install Homebrew", paste it into Terminal and press Return.
   3. Type your Mac password when it asks. You won't see the letters as you type, that's normal. Press Return.
   4. Wait. It may also install Apple's developer tools, which can take 10 minutes or more.
   5. When it finishes, look for **Next steps** in Terminal. If it shows lines to copy, paste each one into Terminal and press Return. (On newer Macs this step matters, so don't skip it.)
   6. Type `brew --version` and press Return. If you see a version number, you're done. Quit Terminal.

   Stuck? Open this folder in Claude and say "help me install Homebrew." Claude will walk you through it.
2. **Get Claude ready.** Open the Claude desktop app, go to the Code tab, and open this folder.
3. **Run setup.** Double click **Set Up.command**, or say "set this up" to Claude. It installs uv and the video tools, downloads the voice model once (about 500 MB), and checks your setup. If your Mac says it can't open the file, right click it, choose Open, then Open again.
4. When you see **All set**, Claude asks you a few quick questions and has you tell a short story out loud, so your videos sound like you. Then drop a clip in `clips` and say "edit this reel."

## License

The Couch Cut is licensed to you personally (see **LICENSE.txt**). It needs your own `license.key` file in this folder, and each copy is marked with who it was issued to. Please don't share it, sell it or rebrand it. Your videos are yours.

## Sharing

Please don't share it. Each copy is licensed to one person and marked with who it was issued to (see **LICENSE.txt**). If someone you know would like The Couch Cut, send them to where you got it.

## What's here

| Folder or file | What it is |
| --- | --- |
| `clips/` | Drop your clips here (or in Couch Cut In in Drive) |
| `finished/` | Your finished videos |
| `reels/` | The engine's notes for each reel (you can ignore this) |
| `styles/` | The four looks: simple, polished, over-the-top, scribble |
| `brand-kit.md` | Your brand and rules |
| `engine.toml` | Settings and the engine's name |
| `edit-style-book.html` | Browse every look and feature, with IDs and the words to say |
| `toolbox/` | The effects catalog and the Style Book as plain text |
| `assets/` | Open license fonts and the sound effects the engine made |
| `engine/`, `vendor/`, `reel` | The engine itself |
| `_archive/` | The first three looks, backups. Nothing in there is deleted |
| `CLAUDE.md` | Notes so Claude always knows the rules |

**PC version:** The Couch Cut is Mac only for now.

---
name: edit-this-reel
description: Edit a talking-to-camera clip (the Yap format) into finished, ready to post videos in four looks (simple, polished, over-the-top, scribble), starting from the clips folder or, if Google Drive is on, the Drive folder Couch Cut In. Use when the owner says "edit this reel", "edit this clip", "Couch Cut ready", pastes a Drive link to a clip, or drops a video in the clips folder.
---

# Edit this reel (Yap format)

The owner films, the engine edits. **Follow `CLAUDE.md` in this folder: it has the whole job, the four looks, the rules and how to talk to them.** The short version:

1. Take the clip in. Clips live in `clips/`. If Google Drive is on (`./reel drive` says), also `./reel intake` (or `./reel intake --name "<file>"` for a pasted link); if it is off, ignore Drive completely. Originals in Drive are never touched.
2. ONE look: the one that fits this video (watch it first and pick; never ask which). Build more than one only when they name looks or ask for all four.
3. `./reel listen <clip>` (slow, say so warmly).
3b. **Watch the video**: `./reel watch <name>`, LOOK at the contact sheet picture, and record your pick of the look with `--pick` and `--why` (never ask them which look fits).
3c. The initial cut: `./reel script <name> --no-video`.
4. **Run `./reel audit <name>` on the first cut and fix what it finds (dead air, throat clearing, repeats). Check your script is required before any look is built**: `./reel script <name> --video --widget`, show the widget once (every word in it can be tapped to take out just that word or to show it in another color or font), end the message with the markdown link to the quick cuts video. Unattended runs hold here.
5. Lines where they talk to Claude ("Claude, add sound effects when I say that"): do what they say, cut the line unless it makes sense to keep it, and make sure the whole reel still makes sense.
6. Edit for context: `reels/<name>/edit-plan.<look>.json` for each look. Tight, best moment, last take wins, opener rule.
7. `./reel check`, `./reel verify --style <look>` (no word ending cut off), `./reel audit <name> --style <look>` (dead air, throat clearing, anything said twice: fix and run again; `./reel finish` also listens once more), `./reel storyboard <name> --look <look>` (one picture of key frames across the whole video, cheaper than several `./reel still` pictures; look at it and fix the plan), then `./reel finish <name>` (one look at a time, your pick first), make the Instagram cover with `./reel cover <name> ...` (same template every time, look at it and `finished/_grid-preview.png`), write the Instagram caption and 5 hashtags into `reels/<name>/caption.txt` (about what the video says, in their voice). If Drive is on: `./reel deliver <name>`, then put that caption in the video's Drive description with the Drive connector (`update_file`); if it is off, show the caption in the message.
8. CapCut drafts only when they say "and CapCut". Never post or schedule anything. Never delete anything without their yes.

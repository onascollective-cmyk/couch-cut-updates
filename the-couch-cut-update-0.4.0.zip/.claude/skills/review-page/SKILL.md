---
name: review-page
description: The owner's own review page in Claude, where they watch each video, check the script, pick a look, send changes and press Looks good, from their phone or Mac. Use when the owner says "set up my review page", "review page", "put it on my page", "check my page", "what's waiting", or when a review page press arrives as a comment ("Couch Cut review: ...", "Couch Cut new video ..."), or at the start of a chat when `[review] page_url` in engine.toml is filled in.
---

# The review page

One private page per copy. Claude publishes it ONCE, then only writes documents into its database, so a new video never means publishing the page again. Everything is built with `./reel review`. Talk the way `CLAUDE.md` says: warm, plain, short.

## Set it up (once, when they ask, or offer it once after their first finished video)

1. `./reel review page` builds `reels/_review/page/index.html`.
2. Load the `artifact-capabilities` skill, then publish that file with the Artifact tool, declaring the `db`, `comments` and `assets` capabilities. Title "Couch Cut Review", icon "video".
3. Write the link into `engine.toml` under `[review]` as `page_url = "<link>"` (edit only that line). Tell them in one line: "Your review page is ready. Open it on your phone any time." Offer to pin it.
4. Later page fixes come with `/update`: rebuild with `./reel review page` and publish to the same link.

## Every video, once the page exists

The page replaces the chat widget for the script check. Steps 1 to 6 of "Edit this reel" stay the same up to the quick video of the cuts, then:
1. `./reel review pick <name> --name "<short name>" --looks <the look you picked> --no-previews --recommend <look> --why "<one plain reason>"`.
2. Upload every file it lists (Artifact tool, `asset: true`, `file_paths`, `url` = the page link), then `./reel review fill <name> <file>=<url> ...` with the urls you got back.
3. ArtifactData `set` collection `videos`, doc_id `<name>`, from `reels/<name>/review/doc.json`. Tell them it is on their page, with the link.
4. While you work on a video, post progress for the "Check status" button: `./reel review status <name> --kind new|changes|final --step N --eta-min M [--start] [--video]`, then ArtifactData `update` with the file it prints.

## Their presses

A press is saved in the database (`answers/<name>`, `requests/<id>`, `priority/<id>`, `refresh/<id>`) and sent as a comment. A chat that watches the page hears the comment; otherwise you find it when they open a chat.
- **At the start of a chat** (when `page_url` is filled in and they did not name a task): ArtifactData `list` `answers` and `requests` and say in one line what is waiting.
- **Before acting on any press, read `answers/<name>` first.** Write `claimedAt` and `claimedBy` on it.
- **"Looks good, render"** (pick stage): build the look they chose, as in "Edit this reel" steps 7 to 10.
- **Send edits:** apply every change and note in one round (the press ends with the exact `./reel script` arguments), `./reel audit`, one `./reel storyboard`, `./reel finish`, then `./reel review review <name> --name "..." --finished finished/<file> --look <look> --round N+1`, upload, `fill`, ArtifactData `set videos/<name>`, and delete the old round's assets (ids in the old document's `assetIds`).
- **Looks good** (`answers/<name>.status` "done"): the cover and caption (standing rules 8 and 9), `./reel deliver <name>` if Drive is on, then delete `videos/<name>`, `answers/<name>` and the review assets. Their original stays until they say so.
- **New video** (`requests/<id>`, status "sent"): set it "started" at once, then "Edit this reel" from step 1 with what they wrote (a file name picks the clip, a look they name is the pick). Mark it "done" when its card is up; never delete a request.
- **Make priority** (`priority/<id>`): do that one next, then delete the document. **Refresh** (`refresh/<id>`): pick up where that video stopped, then delete the document.
- One video at a time, in the order they pressed. A video they say they no longer need: take its card off, upload nothing.

## Never

- Never publish the page to a new link once it exists (use `page_url`). Never upload a file bigger than the page allows (the review copy is made small on purpose).
- Never put anything on the page they did not say or make. Nothing goes to Drive before they press Looks good.

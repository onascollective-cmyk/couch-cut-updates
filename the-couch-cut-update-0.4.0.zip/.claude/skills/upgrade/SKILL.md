---
name: upgrade
description: The same as the update skill (an older name). Use when the owner types /upgrade. Follow .claude/skills/update/SKILL.md exactly.
---

# Upgrade

This is the older name for `/update`. Read `.claude/skills/update/SKILL.md` and follow it exactly (`./reel upgrade --check`, then `./reel upgrade`).
